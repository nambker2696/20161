class StaticPagesController < ApplicationController
  def home
  	
  end
  def about
  	
  end
  def login
  	
  end
  def contact
  	
  end
  def help
  	
  end
  def setting
    
  end
end
