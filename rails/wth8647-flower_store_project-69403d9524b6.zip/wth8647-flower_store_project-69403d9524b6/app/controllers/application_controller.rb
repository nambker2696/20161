class ApplicationController < ActionController::Base
	include SessionsHelper

	def home
		
	end
end
