class Admin::DashboardController < Admin::BaseController
  def home
  end
end
