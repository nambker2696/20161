class CartController < ApplicationController
	def index
		
	end
	def checkout
	end
end
